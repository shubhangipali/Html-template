
(function ($) {
    "use strict";

    var $main_window = $(window);

    /*====================================
    preloader js
    ======================================*/
    $main_window.on("load", function () {
        $(".preloader").fadeOut("slow");
    });
})(jQuery);


$('.team-slider').owlCarousel({
    loop: true,
    margin: 20,
    nav: true,
    dots: false,
    stagePadding: 15,
    navText: ["<i class='fa fa-arrow-left'></i>", "<i class='fa fa-arrow-right'></i>"],
    // autoplay:true,
    // autoplayTimeout:1000,

    autoplayHoverPause: true,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 2
        },
        1000: {
            items: 4
        }
    }
})



/* ===============================  isotope Masonery  =============================== */

$('.gallery').isotope({
    itemSelector: '.items'
});

var $gallery = $('.gallery').isotope();

$('.filtering').on('click', 'span', function () {
    var filterValue = $(this).attr('data-filter');
    $gallery.isotope({ filter: filterValue });
});

$('.filtering').on('click', 'span', function () {
    $(this).addClass('active').siblings().removeClass('active');
});

/* ===============================  Wow Animation  =============================== */

wow = new WOW({
    animateClass: 'animated',
    offset: 100
});
wow.init();
// ==============================================================================================
$('.counter').counterUp({
    delay: 10,
    time: 1000
});



$('#myMosaic').justifiedGallery({
    rowHeight: 300,
    margins: 30,
    randomize: true
});


$('.hamberger-button').on('click', function (e) {
    $('.popup-mobile-menu').addClass('active');
});
$('.close-menu').on('click', function (e) {
    $('.popup-mobile-menu').removeClass('active');
    $('.popup-mobile-menu .mainmenu .has-droupdown > a').siblings('.submenu, .rn-megamenu').removeClass('active').slideUp('400');
    $('.popup-mobile-menu .mainmenu .has-droupdown > a').removeClass('open')
});
$('.popup-mobile-menu .mainmenu .has-droupdown > a').on('click', function (e) {
    e.preventDefault();
    $(this).siblings('.submenu, .rn-megamenu').toggleClass('active').slideToggle('400');
    $(this).toggleClass('open')
})
$('.popup-mobile-menu').on('click', function (e) {
    e.target === this && $('.popup-mobile-menu').removeClass('active') && $('.popup-mobile-menu .mainmenu .has-droupdown > a').siblings('.submenu, .rn-megamenu').removeClass('active').slideUp('400') && $('.popup-mobile-menu .mainmenu .has-droupdown > a').removeClass('open');
});



// =====================================maps=============================================
$(document).ready(function () {

    $('body').noisy({
        intensity: 0.2,
        size: 200,
        opacity: 0.2,
        randomColors: false, // true by default
        color: '#000000'
    });

    //Google Maps JS
    //Set Map
    function initialize() {
        var myLatlng = new google.maps.LatLng(53.3333, -3.08333);
        var imagePath = 'http://m.schuepfen.ch/icons/helveticons/black/60/Pin-location.png'
        var mapOptions = {
            zoom: 11,
            center: myLatlng,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        }

        var map = new google.maps.Map(document.getElementById('map'), mapOptions);
        //Callout Content
        var contentString = 'Some address here..';
        //Set window width + content
        var infowindow = new google.maps.InfoWindow({
            content: contentString,
            maxWidth: 500
        });

        //Add Marker
        var marker = new google.maps.Marker({
            position: myLatlng,
            map: map,
            icon: imagePath,
            title: 'image title'
        });

        google.maps.event.addListener(marker, 'click', function () {
            infowindow.open(map, marker);
        });

        //Resize Function
        google.maps.event.addDomListener(window, "resize", function () {
            var center = map.getCenter();
            google.maps.event.trigger(map, "resize");
            map.setCenter(center);
        });
    }

    google.maps.event.addDomListener(window, 'load', initialize);

});



// <!-- Initialize Swiper -->
var swiper = new Swiper(".mySwiper", {
    slidesPerView: 3,
    spaceBetween: 30,
    slidesPerGroup: 3,
    loop: true,
    loopFillGroupWithBlank: true,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    breakpoints: {
        300: {
            slidesPerView: 1,
            spaceBetween: 20,
        },
        640: {
            slidesPerView: 1,
            spaceBetween: 20,
        },
        768: {
            slidesPerView: 2,
            spaceBetween: 40,
        },
        1024: {
            slidesPerView: 3,
            spaceBetween: 60,
        },
    },
});



// header sticky
window.onscroll = function () { myFunction() };

var header = document.getElementById("myHeader");
var sticky = header.offsetTop;

function myFunction() {
    if (window.pageYOffset > sticky) {
        header.classList.add("sticky");
    } else {
        header.classList.remove("sticky");
    }
}